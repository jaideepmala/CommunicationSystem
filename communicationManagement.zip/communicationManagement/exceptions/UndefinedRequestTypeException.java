package com.amazon.hfchotel.test.communicationManagement.exceptions;

public class UndefinedRequestTypeException extends RuntimeException {

    public UndefinedRequestTypeException(final String message) {

        super(message);
    }
}
